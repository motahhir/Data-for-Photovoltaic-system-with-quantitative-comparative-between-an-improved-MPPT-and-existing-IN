Please, refer to PSIM Tutorial "How to Use Solar Module Physical Model" to adjust series resistance (Rs).


Please cite this work as: 

1. Motahhir, S., El Ghzizal, A., Sebti, S., & Derouich, A. (2018). Modeling of photovoltaic system with modified incremental conductance algorithm for fast changes of irradiance.
International Journal of Photoenergy, 2018.

2. Motahhir, S., El Hammoumi, A., & El Ghzizal, A. (2018). Photovoltaic system with quantitative comparative between an improved MPPT and existing INC and P&O methods under fast
varying of solar irradiation. Energy Reports, 4, 341-350.

3. Motahhir, S., El Ghzizal, A., & Derouich, A. (2015, May). Mod�lisation et commande d'un panneau photovolta�que dans l'environnement PSIM. 
In Congr�s International de G�nie Industriel et Management des Syst�mes.



For more papers and works please visit : 
https://www.researchgate.net/profile/Saad_Motahhir





